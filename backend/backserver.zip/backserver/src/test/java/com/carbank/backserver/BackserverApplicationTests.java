package com.carbank.backserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackserverApplicationTests {

	@Test
	void contextLoads() {
	}

}

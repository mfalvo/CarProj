package com.carbank.backserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackserverApplication.class, args);
	}

}
